package com.yummynoodlebar.rest.domain;

import org.springframework.hateoas.ResourceSupport;

public class PaymentDetails extends ResourceSupport {
}
