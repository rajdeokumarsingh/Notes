package com.yummynoodlebar.rest.domain;

public class PaymentDetails {
}
