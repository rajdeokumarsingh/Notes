package com.yummynoodlebar.core.events;

public class ReadEvent {
  protected boolean entityFound = true;

  public boolean isEntityFound() {
    return entityFound;
  }
}
