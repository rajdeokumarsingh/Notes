package com.yummynoodlebar.core.events;

public class DeleteEvent {
}
