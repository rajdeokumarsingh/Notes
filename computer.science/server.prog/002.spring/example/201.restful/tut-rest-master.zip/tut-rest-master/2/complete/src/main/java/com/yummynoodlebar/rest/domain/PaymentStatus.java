package com.yummynoodlebar.rest.domain;

public class PaymentStatus {
}
