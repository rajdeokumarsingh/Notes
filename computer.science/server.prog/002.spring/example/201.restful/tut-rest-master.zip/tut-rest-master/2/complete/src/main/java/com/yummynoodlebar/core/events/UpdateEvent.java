package com.yummynoodlebar.core.events;

public abstract class UpdateEvent {
}
