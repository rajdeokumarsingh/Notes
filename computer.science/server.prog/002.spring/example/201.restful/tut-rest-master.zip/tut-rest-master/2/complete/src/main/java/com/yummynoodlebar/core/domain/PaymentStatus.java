package com.yummynoodlebar.core.domain;

public class PaymentStatus {
}
