package com.yummynoodlebar.core.events;

public class UpdatedEvent {
}
