package com.yummynoodlebar.core.events;

public class CreateEvent {
}
