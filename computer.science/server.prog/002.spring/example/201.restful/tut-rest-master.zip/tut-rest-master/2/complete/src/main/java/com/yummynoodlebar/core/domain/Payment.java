package com.yummynoodlebar.core.domain;

public class Payment {
}
