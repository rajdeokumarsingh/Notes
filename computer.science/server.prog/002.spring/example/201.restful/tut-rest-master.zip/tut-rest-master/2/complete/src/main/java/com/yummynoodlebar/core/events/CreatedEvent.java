package com.yummynoodlebar.core.events;

public class CreatedEvent {
}
