package com.yummynoodlebar.core.events;

public class RequestReadEvent {
}
