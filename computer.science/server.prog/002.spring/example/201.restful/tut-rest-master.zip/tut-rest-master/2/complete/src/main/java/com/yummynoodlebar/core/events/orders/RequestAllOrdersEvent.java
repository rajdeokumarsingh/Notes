package com.yummynoodlebar.core.events.orders;

import com.yummynoodlebar.core.events.RequestReadEvent;

public class RequestAllOrdersEvent extends RequestReadEvent {
}
