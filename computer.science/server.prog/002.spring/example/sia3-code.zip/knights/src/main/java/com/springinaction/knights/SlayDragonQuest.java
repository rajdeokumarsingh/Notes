package com.springinaction.knights;

public class SlayDragonQuest implements Quest {

  public void embark() throws QuestException {
    System.out.println("Slaying Dragon!");
  }

}
