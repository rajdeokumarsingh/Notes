package com.springinaction.knights;

public interface Knight {
  void embarkOnQuest() throws QuestException;
}
