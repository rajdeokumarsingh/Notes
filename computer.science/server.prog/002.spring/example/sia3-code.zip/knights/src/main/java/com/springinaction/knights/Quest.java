package com.springinaction.knights;

public interface Quest {
  void embark() throws QuestException;
}
