package com.springinaction.knights;

public class Minstrel {
  public void singBeforeQuest() {     //<co id="co_singBefore"/>
    System.out.println("Fa la la; The knight is so brave!");
  }
  
  public void singAfterQuest() {     //<co id="co_singAfter"/>
    System.out.println(
            "Tee hee he; The brave knight did embark on a quest!");
  }
}
