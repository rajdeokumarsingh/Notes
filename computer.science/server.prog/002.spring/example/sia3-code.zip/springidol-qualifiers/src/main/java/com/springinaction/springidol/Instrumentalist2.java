package com.springinaction.springidol;

public class Instrumentalist2 {

}
