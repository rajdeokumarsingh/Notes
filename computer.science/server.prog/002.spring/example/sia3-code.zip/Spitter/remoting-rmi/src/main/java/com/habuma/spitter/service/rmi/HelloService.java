package com.habuma.spitter.service.rmi;

public interface HelloService {
  String sayHello(String name);
}
