package com.habuma.spitter.jmx;

public interface SpittleNotifier {
  void millionthSpittlePosted();
}