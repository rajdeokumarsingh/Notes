package com.habuma.spitter.jmx;
import javax.management.Notification;
import javax.management.NotificationListener;

public class PagingNotificationListener implements NotificationListener {
  public void handleNotification(Notification notification, 
                                 Object handback) {
     // ...
  }
}
