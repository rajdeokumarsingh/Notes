package com.habuma.spitter.jmx;

public interface HomeControllerManagedOperations {
  int getSpittlesPerPage();
  void setSpittlesPerPage(int spittlesPerPage);
}
