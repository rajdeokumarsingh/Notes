package com.habuma.spitter.method;

public @interface Sensitive {

}
