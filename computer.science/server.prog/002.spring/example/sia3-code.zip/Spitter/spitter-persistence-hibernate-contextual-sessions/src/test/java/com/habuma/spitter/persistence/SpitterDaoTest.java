package com.habuma.spitter.persistence;

public class SpitterDaoTest extends AbstractSpitterDaoTest {
} 
