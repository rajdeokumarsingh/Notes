package com.habuma.spitter.alerts;
import com.habuma.spitter.domain.Spittle;

public class SpittleAlertHandler {
  
  public void processSpittle(Spittle spittle) {
    // ... implementation goes here...
  }
 
}
