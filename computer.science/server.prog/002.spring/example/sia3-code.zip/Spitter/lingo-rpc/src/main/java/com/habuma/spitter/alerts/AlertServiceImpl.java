package com.habuma.spitter.alerts;

import com.habuma.spitter.domain.Spittle;

public class AlertServiceImpl implements AlertService {
  public void sendSpittleAlert(final Spittle spittle) {
    // TODO - Fill in the blanks for sending spittle e-mails
  }  
}
