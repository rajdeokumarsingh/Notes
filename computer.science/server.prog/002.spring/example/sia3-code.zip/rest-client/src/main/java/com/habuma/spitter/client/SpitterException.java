package com.habuma.spitter.client;

public class SpitterException extends Exception {
  public SpitterException(String message, Throwable cause) {
    super(message, cause);
  }
}
