package com.habuma.spitter.client;

public class SpittlesNotFoundException extends RuntimeException {

}
