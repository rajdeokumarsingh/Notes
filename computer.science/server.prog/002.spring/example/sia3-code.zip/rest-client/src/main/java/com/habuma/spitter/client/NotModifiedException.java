package com.habuma.spitter.client;

public class NotModifiedException extends RuntimeException {
  private static final long serialVersionUID = 1L;
}
