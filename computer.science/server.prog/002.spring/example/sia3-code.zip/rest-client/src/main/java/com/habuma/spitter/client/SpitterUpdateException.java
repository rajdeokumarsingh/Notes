package com.habuma.spitter.client;

public class SpitterUpdateException extends SpitterException {
  public SpitterUpdateException(String message, Throwable cause) {
    super(message, cause);
  }
}
