package com.springinaction.springidol;

public interface Contestant {
  void receiveAward();
}