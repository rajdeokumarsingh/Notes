// <start id="performer_java" />
package com.springinaction.springidol;

public interface Performer {
  void perform() throws PerformanceException;
}
// <end id="performer_java" />
