package com.springinaction.springidol;

public class Guitar implements Instrument {
  public void play() {
    System.out.println("Strum strum strum");
  }
}
