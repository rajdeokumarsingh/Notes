//<start id="instrument_java" />
package com.springinaction.springidol;

public interface Instrument {
  public void play();
}
// <end id="instrument_java" />
