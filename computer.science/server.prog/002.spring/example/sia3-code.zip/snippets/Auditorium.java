public class Auditorium {
	public void turnOnLights() {
		...
	}
	
	public void turnOffLights() {
		...
	}
}