//<start id="autowire_required_false"/> 
@Autowired(required=false)
private Instrument instrument;
//<end id="autowire_required_false"/> 
