<!--<start id="spitterServiceWsdl"/>--> 
<wsdl:definitions targetNamespace="http://spitter.com">
...
  <wsdl:service name="spitterService"> 
    <wsdl:port name="spitterServiceHttpPort"
            binding="tns:spitterServiceHttpBinding">
...
    </wsdl:port>
  </wsdl:service>
</wsdl:definitions>
<!--<end id="spitterServiceWsdl"/>--> 
