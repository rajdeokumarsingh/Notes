// <start id="thinker_java" />
package com.springinaction.springidol;

public interface Thinker {
  void thinkOfSomething(String thoughts);
}
// <end id="thinker_java" />
