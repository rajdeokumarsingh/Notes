// <start id="mindreader_java" />
package com.springinaction.springidol;

public interface MindReader {
  void interceptThoughts(String thoughts);

  String getThoughts();
}
// <end id="mindreader_java" />
