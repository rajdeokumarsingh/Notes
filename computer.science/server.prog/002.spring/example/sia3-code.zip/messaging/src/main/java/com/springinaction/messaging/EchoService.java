package com.springinaction.messaging;

public interface EchoService {
  void echo(String message);
}
