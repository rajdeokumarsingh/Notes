package com.springinaction.messaging;

public class MessageGetter {
  public void echo(String string) {
    System.out.println("GOT A MESSAGE:  " + string);
  }
}
