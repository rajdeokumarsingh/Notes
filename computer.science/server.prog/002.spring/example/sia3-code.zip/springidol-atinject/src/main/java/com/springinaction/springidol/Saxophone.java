// <start id="piano_java" />
package com.springinaction.springidol;


//@Component
public class Saxophone implements Instrument {
  public Saxophone() {
  }

  public void play() {
    System.out.println("PLINK PLINK PLINK");
  }
}
// <end id="piano_java" />
