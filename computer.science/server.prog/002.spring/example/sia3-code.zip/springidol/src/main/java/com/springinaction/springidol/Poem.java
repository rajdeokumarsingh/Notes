//<start id="poem_java" /> 
package com.springinaction.springidol;

public interface Poem {
  void recite();
}
//<end id="poem_java" />
