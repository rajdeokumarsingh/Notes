//<start id="piano_java" /> 
package com.springinaction.springidol;

public class Piano implements Instrument {
  public Piano() {
  }

  public void play() {
    System.out.println("PLINK PLINK PLINK");
  }
}
//<end id="piano_java" />
