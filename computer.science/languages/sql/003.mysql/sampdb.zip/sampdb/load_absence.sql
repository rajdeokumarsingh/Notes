LOAD DATA LOCAL INFILE "absence.txt" INTO TABLE absence;
