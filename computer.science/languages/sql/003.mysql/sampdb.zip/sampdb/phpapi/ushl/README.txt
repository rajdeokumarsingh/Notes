dump_members.php
  Script to display USHL member list

edit_member.php
  Script that enables USHL member entry editing

index.php, index2.php, index3.php, index4.php, index5.php
  Successive versions of the USHL home page.  Install each one as
  index.php in the ushl directory of your Web server document tree to
  try it.
  - index.php is the initial version.
  - index2.php uses the sampdb_connect helper function in sampdb.php.
  - index3.php uses HTML helper functions to produce the page header and footer.
  - index4.php adds a link for the dump_members.php script.
  - index5.php adds links for the pres_quiz.php and edit_member.php scripts.

pres_quiz.php
  Script to present the president quiz
