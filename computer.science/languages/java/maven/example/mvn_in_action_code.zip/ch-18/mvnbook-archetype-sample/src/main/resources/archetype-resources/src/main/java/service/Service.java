package ${package}.service;

public class Service
{    
}