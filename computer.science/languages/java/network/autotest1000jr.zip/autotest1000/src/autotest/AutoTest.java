package autotest;

import java.util.Iterator;

import testcase3_1.LoginCase;
import testcase3_2.TestPushServer;
import util.Util;

public class AutoTest {
	
	private static String test_host =  "http://192.168.10.234:3342/";

	//private static String PUSH_IP = "http://119.161.242.248:3342/";

	public static void main(String args[]) {
		Util.mSwitch = 0;
		testCase(test_host);
	}

	public static void testCase(String host) {

		log("TEST  开始测试     ------------------------------");
		inittest();
		log("TEST 登录模块--------3.1.1");
		LoginCase mLoginCase = new LoginCase(host);
		mLoginCase.test();

		//log("TEST 获取设备列表--------3.2.1");
		//GetDeviceList mGetDeviceList = new GetDeviceList(host);
		//mGetDeviceList.test();


		//log("TEST push命令--------3.2.16");
		//PushCmd mPushCmd = new PushCmd(host);
		//mPushCmd.test();
 
		log("TEST push命令--------3.2.16");
		String devUUID = "device_uuid_00001";
		TestPushServer mTestPushServerStart = new TestPushServer(devUUID,"start");
		mTestPushServerStart.test();
		for(int i=0;i<1000;i++)
		{
		log("TEST push命令--------3.2.16");
	    devUUID = "device_uuid_00001";
		TestPushServer mTestPushServer = new TestPushServer(devUUID,"kankankankankankankankankankankankan");
		mTestPushServer.test();
		}
		
		devUUID = "device_uuid_00001";
		TestPushServer mTestPushServerEnd = new TestPushServer(devUUID,"end");
		mTestPushServerEnd.test();
		

		log("TEST  内网测试完毕！！！------------------------------\n\n\n");

		if (Util.ErrorLog != null) {
			if (Util.ErrorLog.size() != 0) {
				log("TEST  错误的用例如下  ------------------------------");
				Iterator<String> iterator = Util.ErrorLog.keySet().iterator();
				while (iterator.hasNext()) {
					Object key = iterator.next();
					System.out.println("错误用例名字 :"
							+ Util.ErrorLog.get(key).getTestNUm()
							+ "    错误详情 :"
							+ Util.ErrorLog.get(key).getErrorInfo());
				}
			} else {
				log("TEST  测试全部通过！！！  ------------------------------\n\n\n");
			}
		}
	}

	private static void inittest() {
		log("AutoTest init");
		if (Util.ErrorLog != null) {
			Util.ErrorLog.clear();
		}
	}

	public static void log(String Mes) {
		Util.log(Mes);
	}
}
