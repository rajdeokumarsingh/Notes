package util;

public class Docid {

	int result;
	int docId;

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	public int getDocId() {
		return docId;
	}

	public void setDocId(int docId) {
		this.docId = docId;
	}

	@Override
	public String toString() {
		return "Docid [result=" + result + ", docId=" + docId + "]";
	}

}
