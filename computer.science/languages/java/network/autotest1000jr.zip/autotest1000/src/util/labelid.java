package util;

public class labelid {

	int result;
	int labelId;

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	public int getLabelId() {
		return labelId;
	}

	public void setLabelId(int labelId) {
		this.labelId = labelId;
	}

	@Override
	public String toString() {
		return "labelid [result=" + result + ", labelId=" + labelId + "]";
	}

}
