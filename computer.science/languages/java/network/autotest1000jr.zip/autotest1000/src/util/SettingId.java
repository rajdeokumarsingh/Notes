package util;

public class SettingId {

	int result;
	int settingId;

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	public int getSettingId() {
		return settingId;
	}

	public void setSettingId(int settingId) {
		this.settingId = settingId;
	}

	@Override
	public String toString() {
		return "SettingId [result=" + result + ", settingId=" + settingId + "]";
	}

}
